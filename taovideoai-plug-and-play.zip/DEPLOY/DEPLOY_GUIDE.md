
# TaoVideoAI – Deploy nhanh (local & server)

## Local (Plug & Play)
```bash
cp .env.example .env
docker compose build
docker compose up -d
# Web: http://localhost:3000 , API: http://localhost:8000 , MinIO console: http://localhost:9001
```
Luồng: Tạo project → upload ảnh/video → nhập script → Render → xem MP4.

## Server (self-host)
- Cài Docker/Compose.
- Copy toàn bộ thư mục này lên server.
- `cp .env.example .env` rồi `docker compose up -d --build`.
- Dùng reverse-proxy (Caddy/Nginx) để trỏ domain và bật HTTPS.

> Generated 2025-08-09T13:21:58.445927
