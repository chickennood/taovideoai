
#!/usr/bin/env bash
set -e
python -m app.worker_api &
celery -A app.worker.celery worker --loglevel=INFO
