
from flask import Flask, request, jsonify
from .worker import render_job

app = Flask(__name__)

@app.get('/')
def root():
    return {'ok': True, 'service': 'worker'}

@app.post('/enqueue')
def enqueue():
    data = request.get_json()
    job = render_job.delay(data['project_id'], data)
    return jsonify({"job_id": job.id})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
