
import os
from sqlalchemy import create_engine, text
from boto3.session import Session

DB = os.getenv("DATABASE_URL")
S3_ENDPOINT = os.getenv("S3_ENDPOINT")
S3_ACCESS_KEY = os.getenv("S3_ACCESS_KEY")
S3_SECRET_KEY = os.getenv("S3_SECRET_KEY")
S3_BUCKET = os.getenv("S3_BUCKET")

engine = create_engine(DB, future=True)

session = Session()
s3 = session.client(
    service_name="s3",
    endpoint_url=S3_ENDPOINT,
    aws_access_key_id=S3_ACCESS_KEY,
    aws_secret_access_key=S3_SECRET_KEY,
)

def update_job(jid: str, progress: int, msg: str = ""):
    with engine.begin() as conn:
        conn.execute(text("UPDATE jobs SET progress=:p, status=:s, meta=:m WHERE id=:id"),
                     {"p": progress, "s": "running", "m": {"msg": msg}, "id": jid})

def finish_job(jid: str, url: str):
    with engine.begin() as conn:
        conn.execute(text("UPDATE jobs SET status='done', progress=100, output_url=:u WHERE id=:id"),
                     {"u": url, "id": jid})

def put_bytes(data: bytes, suffix: str) -> str:
    import uuid
    key = f"outputs/{uuid.uuid4()}.{suffix}"
    s3.put_object(Bucket=S3_BUCKET, Key=key, Body=data, ACL="public-read")
    return f"{S3_ENDPOINT.replace('minio','localhost')}/{S3_BUCKET}/{key}"
