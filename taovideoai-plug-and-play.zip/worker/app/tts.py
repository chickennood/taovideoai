
from gtts import gTTS
import tempfile, os

def synthesize(script: str, lang: str = "vi") -> str:
    tts = gTTS(text=script, lang=lang)
    fd, path = tempfile.mkstemp(suffix=".mp3"); os.close(fd)
    tts.save(path)
    return path
