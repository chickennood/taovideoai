
import io, requests, tempfile, os
from moviepy.editor import AudioFileClip, VideoFileClip, ImageClip
from .media import put_bytes, finish_job
from .tts import synthesize

def _fetch(url: str) -> bytes:
    r = requests.get(url, timeout=60); r.raise_for_status(); return r.content

def _segments(text: str):
    words = text.split()
    segs, chunk = [], []
    for w in words:
        chunk.append(w)
        if len(chunk) >= 8:
            segs.append(" ".join(chunk)); chunk=[]
    if chunk: segs.append(" ".join(chunk))
    return [(i*3, (i+1)*3, seg) for i, seg in enumerate(segs)]

def _burn_subs(clip, text: str):
    from moviepy.editor import TextClip, CompositeVideoClip
    subs = []
    for (t0, t1, seg) in _segments(text):
        txt = TextClip(seg, fontsize=42, font="DejaVu-Sans", method='caption', size=(clip.w*3//4, None))
        txt = txt.set_position(('center','bottom')).set_duration(t1-t0).set_start(t0)
        subs.append(txt)
    return CompositeVideoClip([clip, *subs])

def run_pipeline(job_id: str, project_id: str, opts: dict, progress):
    progress(5, "Chuẩn bị")
    script = (opts.get("script") or "").strip()
    bg_url = opts.get("background_url")
    if not bg_url: raise RuntimeError("Thiếu background_url")

    audio_path = None
    if script:
        progress(20, "Tạo giọng nói")
        audio_path = synthesize(script, lang="vi")

    progress(40, "Tạo nền")
    data = _fetch(bg_url)
    fd, bg_path = tempfile.mkstemp(suffix='.'+bg_url.split('.')[-1]); os.write(fd, data); os.close(fd)

    if bg_path.lower().endswith((".png",".jpg",".jpeg")):
        duration = max(6, len(script)//10 or 9)
        clip = ImageClip(bg_path, duration=duration).set_fps(30)
    else:
        v = VideoFileClip(bg_path)
        clip = v.subclip(0, min(15, int(v.duration)))

    if audio_path:
        progress(60, "Gắn âm thanh")
        aclip = AudioFileClip(audio_path)
        clip = clip.set_audio(aclip).set_duration(aclip.duration)

    if script:
        progress(75, "Phụ đề")
        clip = _burn_subs(clip, script)

    progress(90, "Xuất video")
    out_path = "/tmp/out.mp4"
    clip.write_videofile(out_path, codec="libx264", audio_codec="aac", fps=30, temp_audiofile="/tmp/audtmp.m4a", remove_temp=True, verbose=False, logger=None)
    with open(out_path, "rb") as f:
        url = put_bytes(f.read(), "mp4")
    finish_job(job_id, url)
    progress(100, "Xong")
    return {"output_url": url}
