
import os
from celery import Celery
from .pipeline import run_pipeline
from .media import update_job

celery = Celery(broker=os.getenv("REDIS_URL"), backend=os.getenv("REDIS_URL"))

@celery.task(bind=True)
def render_job(self, project_id: str, opts: dict):
    def progress(p, msg=""):
        self.update_state(state="PROGRESS", meta={"p": p, "msg": msg})
        update_job(self.request.id, p, msg)
    return run_pipeline(self.request.id, project_id, opts, progress)
