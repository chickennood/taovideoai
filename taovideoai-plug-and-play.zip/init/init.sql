
CREATE TABLE IF NOT EXISTS projects (
  id varchar(64) PRIMARY KEY,
  name varchar(200) NOT NULL,
  aspect_ratio varchar(10) DEFAULT '9:16'
);
CREATE TABLE IF NOT EXISTS assets (
  id varchar(64) PRIMARY KEY,
  project_id varchar(64) REFERENCES projects(id),
  kind varchar(16),
  url text
);
CREATE TABLE IF NOT EXISTS jobs (
  id varchar(64) PRIMARY KEY,
  project_id varchar(64) REFERENCES projects(id),
  type varchar(20),
  status varchar(20) DEFAULT 'queued',
  progress integer DEFAULT 0,
  meta jsonb,
  output_url text
);
