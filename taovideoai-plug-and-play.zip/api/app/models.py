
from pydantic import BaseModel
class CreateProject(BaseModel):
    name: str
    aspect_ratio: str = "9:16"

class RenderRequest(BaseModel):
    script: str | None = None
    voice: str = "vi_female_1"
    music_url: str | None = None
    template: str = "clean"
    background_url: str | None = None
    tts: str | None = "gtts"
