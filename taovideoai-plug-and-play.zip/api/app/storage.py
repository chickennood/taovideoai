
import boto3, uuid
from .settings import settings

session = boto3.session.Session()
s3 = session.client(
    service_name="s3",
    endpoint_url=settings.S3_ENDPOINT,
    aws_access_key_id=settings.S3_ACCESS_KEY,
    aws_secret_access_key=settings.S3_SECRET_KEY,
)

def s3_put_bytes(data: bytes, suffix: str) -> str:
    key = f"uploads/{uuid.uuid4()}.{suffix}"
    s3.put_object(Bucket=settings.S3_BUCKET, Key=key, Body=data, ACL="public-read")
    return f"{settings.S3_ENDPOINT.replace('minio','localhost')}/{settings.S3_BUCKET}/{key}"

async def s3_put_fileobj(file, filename: str) -> str:
    ext = filename.split(".")[-1].lower()
    key = f"uploads/{uuid.uuid4()}.{ext}"
    s3.upload_fileobj(file, settings.S3_BUCKET, key, ExtraArgs={"ACL": "public-read"})
    return f"{settings.S3_ENDPOINT.replace('minio','localhost')}/{settings.S3_BUCKET}/{key}"
