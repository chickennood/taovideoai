
from pydantic import BaseModel
class JobOut(BaseModel):
    id: str
    status: str
    progress: int
    output_url: str | None = None
    meta: dict | None = None
