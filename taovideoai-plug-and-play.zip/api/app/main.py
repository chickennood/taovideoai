
from fastapi import FastAPI, UploadFile, File, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from .db import Base, engine, Project, Asset, Job
from .models import CreateProject, RenderRequest
from .deps import get_db
from .storage import s3_put_fileobj
import requests

Base.metadata.create_all(engine)

app = FastAPI(title="TaoVideoAI API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {"ok": True, "service": "api"}

@app.post("/projects")
def create_project(p: CreateProject, db: Session = Depends(get_db)):
    proj = Project(name=p.name, aspect_ratio=p.aspect_ratio)
    db.add(proj); db.commit(); db.refresh(proj)
    return {"id": proj.id}

@app.get("/projects")
def list_projects(db: Session = Depends(get_db)):
    items = db.query(Project).all()
    return {"items": [{"id": x.id, "name": x.name, "aspect_ratio": x.aspect_ratio} for x in items]}

@app.get("/projects/{pid}")
def get_project(pid: str, db: Session = Depends(get_db)):
    p = db.get(Project, pid)
    return {"id": p.id, "name": p.name, "aspect_ratio": p.aspect_ratio}

@app.post("/projects/{pid}/assets")
async def upload_asset(pid: str, file: UploadFile = File(...), db: Session = Depends(get_db)):
    url = await s3_put_fileobj(file.file, file.filename)
    a = Asset(project_id=pid, kind=_kind(file.filename), url=url)
    db.add(a); db.commit(); db.refresh(a)
    return {"id": a.id, "url": a.url, "kind": a.kind}

def _kind(name: str) -> str:
    ext = name.split(".")[-1].lower()
    if ext in ["mp4","mov","mkv","webm"]: return "video"
    if ext in ["mp3","wav","m4a"]: return "audio"
    if ext in ["png","jpg","jpeg"]: return "image"
    if ext in ["srt","vtt"]: return "subtitle"
    return "other"

@app.post("/projects/{pid}/render")
def render(pid: str, body: RenderRequest, db: Session = Depends(get_db)):
    r = requests.post("http://worker:8080/enqueue", json={"project_id": pid, **body.dict()})
    job = r.json()
    j = Job(id=job["job_id"], project_id=pid, type="render", status="queued")
    db.add(j); db.commit()
    return job

@app.get("/jobs/{jid}")
def job_status(jid: str, db: Session = Depends(get_db)):
    j = db.get(Job, jid)
    return {"id": j.id, "status": j.status, "progress": j.progress, "output_url": j.output_url, "meta": j.meta}
