
import './globals.css'
export const metadata = { title:'TaoVideoAI', description:'Tạo video AI trong vài phút' }
export default function RootLayout({ children }: any){
  return <html lang="vi"><body>{children}</body></html>
}
