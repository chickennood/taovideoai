
'use client'
import { useState } from 'react'
import { jfetch, API } from './api-proxy'

export default function Page(){
  const [pid, setPid] = useState('')
  const [name, setName] = useState('Video của tôi')
  const [file, setFile] = useState<File|null>(null)
  const [script, setScript] = useState('Xin chào! Đây là video được tạo bằng TaoVideoAI bản Plug & Play.')
  const [job, setJob] = useState<any>(null)
  const [jobData, setJobData] = useState<any>(null)

  const create = async () => {
    const p = await jfetch('/projects', { method:'POST', body: JSON.stringify({ name, aspect_ratio:'9:16' }) })
    setPid(p.id)
  }
  const render = async () => {
    if (!pid || !file) return
    const form = new FormData(); form.append('file', file)
    const asset = await fetch(`${API}/projects/${pid}/assets`, { method:'POST', body: form }).then(r=>r.json())
    const r = await jfetch(`/projects/${pid}/render`, { method:'POST', body: JSON.stringify({ script, background_url: asset.url }) })
    setJob(r)
    const t = setInterval(async () => {
      const s = await jfetch(`/jobs/${r.job_id}`)
      setJobData(s); if (s.status === 'done') clearInterval(t)
    }, 1000)
  }

  return (
    <main className="container py-10 space-y-6">
      <h1 className="text-3xl font-bold">TaoVideoAI – Plug & Play</h1>
      <div className="card p-4 space-y-2">
        <label className="font-medium">Tên project</label>
        <div className="flex gap-2">
          <input className="input flex-1" value={name} onChange={e=>setName(e.target.value)} />
          <button onClick={create} className="btn-primary">Tạo project</button>
        </div>
        {pid && <p className="text-sm text-muted">Project ID: {pid}</p>}
      </div>
      <div className="card p-4 space-y-2">
        <label className="font-medium">Nền (ảnh/video)</label>
        <input type="file" onChange={e=>setFile(e.target.files?.[0]||null)} />
      </div>
      <div className="card p-4 space-y-2">
        <label className="font-medium">Script</label>
        <textarea className="input h-40" value={script} onChange={e=>setScript(e.target.value)} />
      </div>
      <button onClick={render} className="btn-primary">Render</button>
      {jobData && (
        <div className="card p-4">
          <p>Trạng thái: {jobData.status} – {jobData.progress}%</p>
          {jobData.output_url && <video src={jobData.output_url} controls className="mt-3 w-full" />}
        </div>
      )}
    </main>
  )
}
